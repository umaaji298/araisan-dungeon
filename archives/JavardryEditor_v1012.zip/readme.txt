
JavardryEditor  Ver1.012
￣￣￣￣￣￣￣￣￣￣￣￣
【  種  別  】  フリーソフト
【 作 者 名 】  THU
【作者サイト】  http://thu.sakura.ne.jp/
【 連 絡 先 】  madpoet@thu.sakura.ne.jp

　JavardryEditorはJava製のWizクローンであるJavardryのシナリオデータ
作成用のエディタです。詳しくはマニュアルを見て下さい。

●免責事項
　作者は、当ソフトを利用することで発生したいかなる問題においても
一切責任を負わないものとします。


●利用素材等

　Windows用起動プログラムとして、下記のソフトを
　利用させていただきました。
　-----------------------------------------------
　JavaStarter for Windows

　「The MIZUBASHOW」
　http://homepage1.nifty.com/mizubashow/
　-----------------------------------------------
