
Javardry  Ver1.027
￣￣￣￣￣￣￣￣￣
【  種  別  】  フリーソフト
【 作 者 名 】  THU
【作者サイト】  http://thu.sakura.ne.jp/
【 連 絡 先 】  madpoet@thu.sakura.ne.jp

　JavardryはJava製のWizクローンです。詳しくはマニュアルを見て下さい。

●免責事項
　作者は、当ソフトを利用することで発生したいかなる問題においても
一切責任を負わないものとします。

●利用素材等

○Windows用起動プログラムとして、下記のソフトを
　利用させていただきました。
　-----------------------------------------------
　JavaStarter for Windows

　「The MIZUBASHOW」
　http://homepage1.nifty.com/mizubashow/
　-----------------------------------------------

○以下の背景画像は、下記のサイトの素材を
　利用させていただきました。
　-----------------------------------------------
　[castleTown.png], [edgeOfTown.png], [inn.png]
　[shop.png], [tavern.png], [temple.png]
　[trainingGround.png]

　「誰そ彼亭」
　http://may.force.mepage.jp/
　-----------------------------------------------

○以下の画像は、下記のサイトの
　素材を加工して利用させていただきました。
　-----------------------------------------------
　[none(_HR).jpg], [noneUndecided(_HR).jpg]
　[type00(_HR).jpg ～ type14(_HR).jpg]
　[type00Undecided(_HR).jpg ～ type14Undecided(_HR).jpg]
　[title(_HR).png], [boxClose(_HR).png], [boxOpen(_HR).png]
　[restInPeace(_HR).png]
　[doubleDoor(_HR).png], [stone(_HR).png]

　イラスト投稿コミュニティサイト「pixiv」内、
　「とり夫」氏プロフィールページ
　http://www.pixiv.net/member.php?id=5887541
　-----------------------------------------------

○以下の効果音は、下記のサイトの素材を
　利用させていただきました。
　-----------------------------------------------
　[alarm.wav], [arrow.wav], [chute.wav], [critical.wav]
　[levelUp.wav], [stun.wav], [walk.wav], [wall.wav]

　「WEB WAVE LIB」
　http://wwl.s-t-t.com/
　-----------------------------------------------
　[attack.wav], [battlestart.wav], [battlewin.wav]
　[bomb.wav], [cancel.wav], [enter.wav], [heal.wav]
　[hit.wav], [kickdoor.wav], [select.wav]

　「ザ・マッチメイカァズ」
　http://osabisi.sakura.ne.jp/m2/
　-----------------------------------------------
　[spell.wav]

　「otosozai.com」
　http://otosozai.com/
　-----------------------------------------------

○以下の音楽は、下記のサイトの素材を
　利用させていただきました。
　-----------------------------------------------
　[annihilate.mid]
	モーツァルト：レクイエム ニ短調 K.V.626 Tuba Mirum
　[battle.mid]
	バッハ：イギリス組曲 第6番 ニ短調 BWV811 Gigue
　[boss.mid]
	バッハ：デュエット I ホ短調 BWV802
　[camp.mid]
	バッハ（？）：トリオソナタ ニ短調 BWV1036 Vivace
　[castle.mid]
	バッハ：371の4声のコラール BWV3/6 "Ach Gott, wie manches Herzeleid"
　[castletown.mid]
	バッハ：インヴェンション15 ロ短調 BWV786
　[dungeon.mid]
	バッハ：ミサ曲 ロ短調 BWV232 第3曲 Kyrie eleison
　[edgeoftown.mid]
	バッハ：ミサ曲 ロ短調 BWV232 Benedictus
　[ending.mid]
	バッハ：チェンバロ協奏曲 第2番 ホ長調 BWV1053 (Allegro)
　[inn.mid]
	バッハ：シンフォニア 第6番 ホ長調 BWV792
　[opening.mid]
	バッハ：2つのヴァイオリンのための協奏曲 ニ短調 BWV1043 Vivace
　[shop.mid]
	バッハ：チェンバロ、フルートとヴァイオリンのための協奏曲 イ短調
				BWV1044 Adagio, ma non tanto, e dolce
　[tavern.mid]
	バッハ：無伴奏チェロ組曲 第1番 ト長調 BWV1007 Menuet I
　[temple.mid]
	バッハ：パストラーレ ヘ長調 BWV590 第3楽章

　「KCNのホームページ」
　（大分以前に消滅してますが、ファイルはそのまま使わせて頂いてます。
　　内容を改変せず、KCN氏の名前を明記しておけば問題ない……と思われます）
　-----------------------------------------------

○その他
　その他のファイルは製作者（THU）が作成したものです。
　Javardry用に使うのであれば、改変でもなんでも好きに
　使って下さい。



